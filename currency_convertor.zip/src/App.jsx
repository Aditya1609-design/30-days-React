import { useState, useEffect } from 'react';

function App() {
  const [amount, setAmount] = useState(1);
  const [from, setFrom] = useState('USD');
  const [to, setTo] = useState('INR');
  const [result, setResult] = useState(null);

  useEffect(() => {
    if (from === to) {
      setResult(amount);
      return;
    }

    fetch(`https://api.exchangerate-api.com/v4/latest/${from}`)
      .then(res => res.json())
      .then(data => {
        const rate = data.rates[to];
        setResult((amount * rate).toFixed(2));
      });
  }, [amount, from, to]);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-100 p-4">
      <h1 className="text-3xl font-bold mb-4">Currency Convertor</h1>
      <div className="flex gap-4 mb-4">
        <input
          type="number"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          className="border p-2 rounded"
        />
        <select value={from} onChange={(e) => setFrom(e.target.value)} className="border p-2 rounded">
          <option>USD</option>
          <option>INR</option>
          <option>EUR</option>
          <option>JPY</option>
        </select>
        <span className="text-xl">to</span>
        <select value={to} onChange={(e) => setTo(e.target.value)} className="border p-2 rounded">
          <option>USD</option>
          <option>INR</option>
          <option>EUR</option>
          <option>JPY</option>
        </select>
      </div>
      <div className="text-xl font-semibold">
        {result ? `${amount} ${from} = ${result} ${to}` : 'Converting...'}
      </div>
    </div>
  );
}

export default App;
