export default function App() {
  return (
    <div className="text-3xl font-bold text-blue-600 p-4">
      ✅ Tailwind is working!
    </div>
  )
}
