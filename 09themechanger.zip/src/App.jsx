export default function App() {
  return (
    <div className="flex h-screen items-center justify-center bg-gray-900 text-white text-3xl">
      🚀 Tailwind + React + Vite is ready!
    </div>
  );
}