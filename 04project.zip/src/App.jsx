function App() {
  return (
    <div className="text-center mt-20 text-3xl text-blue-500 font-bold">
      Hello Vite + React + Tailwind!
    </div>
  )
}

export default App
